package com.ecommerce.project.payload;

import lombok.Data;

@Data
public class OrderStatusUpdateDto {
    private String status;
}
